1. Ekstrakcja danych
2. Transformacja danych
	1. Czyszczenie danych
	2. Integracja danych
3. Ładowanie danych
	1. Monitorowanie zmian
	2. Odświeżanie danych