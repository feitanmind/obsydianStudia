<table style="border:1px solid white;border-collapse: collapse;">
	<tr>
	<th></th><th>OLTP</th><th>OLAP</th>
	</tr>
	<tr>
	<td>Użytkownik</td><td>"zwykły"</td><td>Analityk</td>
	</tr>
	<tr>
	<td>Funkcja</td><td>Bieżące operacje, kluczowe dla działania firmy</td><td>Wspomaganie decyzji</td>
	</tr>
	<tr>
	<td>Dane</td>
	<td>Bieżące elementarne</td>
	<td>Elementarne, zagregowane, historyczne</td>
	</tr>
	<tr>
	<td>Aplikacje</td>
	<td>Powtarzalność działań</td>
	<td>Ad hoc</td>
	</tr>
	<tr>
	<td>Dostęp</td>
	<td>Odczyt/Zapis</td>
	<td>Odczyt</td>
	</tr>
	<tr>
	<td>Transakcja</td>
	<td>Krótka</td>
	<td>Długa</td>
	</tr>
	<tr>
	<td>i. przetwarzanych rek.</td>
	<td>Kilka, kilkadziesiąt</td>
	<td>Miliony</td>
	</tr>
	<tr>
	<td>i. użytkowników</td>
	<td>Kilkudziesięciu, setki</td>
	<td>Kilku kilkunastu</td>
	</tr>
	<tr>
	<td>Rozmiar</td>
	<td>Setki GB</td>
	<td>Dziesiątki TB</td>
	</tr>
</table>


