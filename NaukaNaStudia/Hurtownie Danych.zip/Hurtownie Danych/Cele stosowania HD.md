1. Zapewnienie jednolitego dostępu do wszystkich danych gromadzonych w ramach przedsiębiorstwa
2. Dostarczenie technologii przetwarzania analitycznego - technologii OLAP
	1. Wykonywanie zaawansowanych analiz wspomagających zarządzanie przedsiębiorstwem, np:
		1. Analiza trendów sprzedaży
		2. Analiza nakładów reklamowych i zysków
		3. Analiza ruchu telefonicznego
	2. Eksploracja danych
	3. Analiza rozwiązań alternatywnych (what-if analysis)
		1. Symulowanie i przewidywanie przyszłości