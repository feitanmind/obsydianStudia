1. **Bankowość** (np. identyfikacja czynników ryzyka wskazujących, którzy klienci gwarantują bezpieczne spłacanie udzielanego kredytu)
2. **Rynki finansowe** (np. identyfikacja trendów w zakresie akcji spółek giełdowych)
3. **Telekomunikacja** (np. identyfikacja klientów zainteresowanych nowymi usługami i nowymi warunkami współpracy z firmą)
4. **Medycyna** - analiza efektywności procedur leczenia pacjentów