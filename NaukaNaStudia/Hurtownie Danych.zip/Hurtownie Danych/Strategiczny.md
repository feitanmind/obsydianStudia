- Działania strategiczne związane są z planowaniem strategii w firmie.
- Pytania na które odpowiedziałby system o charakterze strategicznym to:
	- **Która linia produktowa zwiększa swoją popularność, a która ją traci?**
	- Które linie produktowe są sezonowe?
	- Czy klienci mają tendencje do zamawiania określonych produktów?
- Te pytania nie są o stan obecny i zwykłe systemy operacyjne nie są dobre w odpowiadaniu na nie.
- Wszystkie te pytania związane są ze **sprzedażą produktów w czasie**
### Strategia
Przyglądając się pytaniu pierwszemu: **Która linia produktowa zwiększa swoją popularność, a która ją traci?**
Jest to sensowne pytanie **strategiczne**.Pytanie, które powinni zadać sobie dyrektorzy firmy. I w zależności od odpowiedzi mogą np. Zwiększyć nakłady na promocję i reklamę produktów, które tracą na popularności.