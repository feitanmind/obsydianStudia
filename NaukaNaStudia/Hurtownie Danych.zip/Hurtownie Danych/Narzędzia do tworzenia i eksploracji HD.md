Hurtownia danych jest złożonym systemem informatycznym.
Różne komponenty są użyteczne przy budowie i eksploracji. Oprogramowanie to można podzielić na kilka kategorii:
- Narzędzia wspomagające projektowanie systemów
- Słowniki(repozytoria) metadanych
- Oprogramowanie typu middleware
- Systemy zarządzania bazami danych
- Narzędzia analityczne
