- **Gwiazda** *(ang. star schema)* 
  ![[Pasted image 20240603201623.png]]
- **Płatek śniegu** *(ang. snowflake schema)*
  ![[Pasted image 20240603201711.png]]
- **Konstelacja faktów** *(ang. fact constelation schema)*
  ![[Pasted image 20240603201808.png]]
  