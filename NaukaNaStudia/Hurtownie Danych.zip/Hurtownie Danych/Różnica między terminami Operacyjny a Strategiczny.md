
Ważne jest aby zrozumieć różnicę pomiędzy terminami [[Operacyjny]]  oraz [[Strategiczny]]. 
*W skrócie działanie strategiczne jest związane z planowaniem strategii, a operacyjne związane z codziennym prowadzeniem interesów firmy.*