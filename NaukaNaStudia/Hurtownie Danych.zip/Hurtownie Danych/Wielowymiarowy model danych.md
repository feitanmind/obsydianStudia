<span style="color: gray;"><i>(ang. Multidimension Data Model)</i></span>
- Podstawowy model logiczny dla MDD/OLAP
- Dane są postrzegane przez użytkowników w postaci wielowymiarowej perspektywy (tzw. kostki OLAP)
- Obiektem analizy jest zbór miar numerycznych - fakty
- Fakt opisuje pojedyncze zdarzenie, o którym informację chcemy przechować w HD
- Fakt jest daną ilościową (numeryczną) reprezentującą jednostkę aktywności biznesowej przedsiębiorstwa, np. średnia ocena studenta, zysk, wartość produktu krajowego, itp.
![[Pasted image 20240603201122.png]]