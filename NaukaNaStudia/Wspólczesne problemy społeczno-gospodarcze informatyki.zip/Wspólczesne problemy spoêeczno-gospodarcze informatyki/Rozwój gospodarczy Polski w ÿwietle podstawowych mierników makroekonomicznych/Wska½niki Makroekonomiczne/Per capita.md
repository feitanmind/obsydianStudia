**Wskaźniki "per capita"** oznaczają wskaźniki na osobę. Są one używane do przedstawienia statystyk gospodarczych, demograficznych lub innych na jednostkę ludności, co umożliwia bardziej szczegółowe porównanie między krajami lub regionami, niezależnie od ich całkowitej liczby ludności. 
Oto wyjaśnienie dwóch głównych wskaźników per capita:
