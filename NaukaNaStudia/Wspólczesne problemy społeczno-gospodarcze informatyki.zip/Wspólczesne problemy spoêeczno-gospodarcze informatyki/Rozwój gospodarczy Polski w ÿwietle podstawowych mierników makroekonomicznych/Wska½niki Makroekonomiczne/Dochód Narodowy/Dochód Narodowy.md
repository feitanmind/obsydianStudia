**Dochód narodowy** jest to ekonomiczna miara produkcji wytworzonej w danym czasie za pomocą czynników produkcji należących do obywateli danego kraju (niezależnie od miejsca ich użycia), wyrażona w cenach tych czynników.

Punktem wyjścia do obliczenia wielkości dochodu narodowego jest wartość produktu krajowego brutto[[Produkt krajowy brutto (PKB)]] w cenach rynkowych.

PKB w cenach rynkowych jest sumą wartości dodanych powstałych w danym okresie w poszczególnych procesach produkcyjnych. Stosując jako kryterium podmiot nabywający wytworzoną produkcję, PKB w cenach rynkowych, powstały w danym czasie (t), dzieli się na 4 części
<code>PKB(t) = C(t) + I(t) + G(t) + EN(t)</code>

<pre>
C(t) to wartość dóbr i usług nabytych przez krajowe gospodarstwa domowe
dla celów konsumpcyjnych
I(t) to suma wartości dóbr i usług nabytych przez krajowe podmioty
prowadzące działalność gospodarczą oraz wartości zmiany poziomu
zapasów (produktów gotowych, produkcji niezakończonej), w okresie
dla którego wyznacza się PKB
G(t) to wydatki państwa na zakup dóbr i usług, finansowane z 
przychodów sektora budżetowego
EN(t) to różnica między eksportem oraz importem
</pre>

Do PKB **nie zalicza się** wydatków transferowych państwa, np. emerytur i rent, zasiłków dla bezrobotnych, dotacji dla przedsiębiorstw państwowych, kosztów obsługi dlugu publicznego.
Po PKB **nie wliczamy** też m.in. transakcji nierynkowych, transakcji nietowarowych, transakcji nieproduktywnych

---
Polska jest jednym z szybko rozwijających się krajów w Europie, a jej dochód narodowy ciągle rośnie. Wzrost gospodarczy Polski oparty jest na różnych sektorach, w tym na produkcji przemysłowej, budownictwie, handlu i usługach, które w znaczący sposób przyczyniają się do dochodu narodowego.
Według Banku Światowego, Dochód Narodowy Brutto per capita Polski gwałtownie wzrósł w ciągu ostatnich kilkudziesięciu lat. Na przykład, w 1990 roli wynosił 1610 dolarów amerykańskich, a w 2019 roku - 15360 dolarów amerykańskich, co pokazuje znaczny wzrost gospodarczy kraju.
[[Czynniki kształtujące Dochód Narodowy Polski]]