**Produkt Krajowy Brutto (PKB)** to wartość wszystkich towarów i usług wytworzonych w danym kraju w ciągu roku przez krajowe czynniki produkcji, niezależnie od tego, czy są one w posiadaniu obywateli danego kraju, czy też obcokrajowców. PKB jest miernikiem wielkości gospodarki oraz jej wydajności i jest często używany do analizowania tempa wzrostu gospodarczego i dobrobytu narodu. 
PKB może być mierzony na kilka sposobów, z których najpopularniejsze to:
- [[Metoda dochodowa]]
- [[Metoda wydatkowa]]
- [[Metoda produkcji (wartości dodanej)]]

---
**PKB wyrównany sezonowo i PKB niewyrównany sezonowo**

**Wyrównanie sezonowe** polega na eliminacji efektu zmienności kalendarzowej i zmienności dni roboczych (różnice czasu pracy w kolejnych miesiącach) oraz efektu sezonowości (coroczne, regularne odchylenia od trendu obserwowane w cyklu rocznym).

**Niewyrównanie sezonowe** nie uwzględnia fluktuacji w gospodarce, takich jak zmiany w konsumpcji w okresach świątecznych czy sezonowe wzrosty produkcji w rolnictwie. Jest to sposób analizy który pozwala zobaczyć rzeczywisty trend wzrostu lub spadku gospodarczego, niezakłócony przez sezonowe wahania.

W przeciwieństwie do PKB wyrównywanego sezonowo, który jest korygowany o te sezonowe zmiany, PKB niewyrównany sezonowo nie podlega temu procesowi. Jest to szczególnie przydatne w analizie długoterminowych trendów gospodarczych oraz porównywaniu danych z różnych okresów.