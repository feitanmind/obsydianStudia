**Wskaźnik HDI** - indeks rozwoju społecznego, ang. Human Development Index (HDI), ekonomiczna miara rozwoju społecznego, określająca poziom społecznego rozwoju danego kraju w stosunku do innych krajów.

Jest obliczany na podstawie danych dotyczących podziału dochodów, wydłużania trwania ludzkiego życia, poziomu osiągnięć edukacyjnych. Przy wyznaczaniu HDI uwzględnia się wartości skrajne poszczególnych wskaźników:
- Przeciętne dalsze trwanie życia
- Przeciętna liczba lat nauki w szkole
- Wskaźnik umiejętności czytania ze zrozumieniem i pisania
- PKB na głowę mieszkańca liczonego według parytetu siły nabywczej.