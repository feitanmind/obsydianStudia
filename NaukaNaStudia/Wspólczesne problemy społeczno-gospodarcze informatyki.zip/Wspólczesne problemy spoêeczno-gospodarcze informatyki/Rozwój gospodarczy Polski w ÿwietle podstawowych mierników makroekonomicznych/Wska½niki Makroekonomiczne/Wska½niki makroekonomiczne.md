- [[Produkt krajowy brutto (PKB)]] - czyli produkt krajowy brutto 
- [[Produkt narodowy brutto (PNB)]]
- [[Per capita]]
- [[Dochód Narodowy]]
- [[Wskaźnik HDI]]

- **PKB** czyli produkt krajowy brutto + dochody netto z tytułu pracy lub własności za granicą 
- **Produkt Narodowy Brutto (PNB)** (różnica między dochodami obywateli danego kraju osiągniętymi za granicą a odpływem dochodów należnych cudzoziemcom)
- **Produkt Narodowy Netto** = PNB - amortyzacja (zużycie majątku)
- **Dochód Narodowy (DN)** = Produkt Narodowy Netto - podatki pośrednie (VAT, AKCYZA) 
---
### Wnioski
Analiza podstawowych mierników makroekonomicznych wskazuje na dynamiczny rozwój gospodarczy Polski w ostatnich latach. Wzrost PKB stabilna stopa bezrobocia oraz zdrowa sytuacja inflacyjna są głównymi wskaźnikami świadczącymi o pozytywnych tendencjach w polskiej gospodarce.

Wzrost PKB odzwierciedla zwiększenie produkcji i dochodów kraju, co może być interpretowane jako wyraz efektywności działań gospodarczych oraz inwestycji. Polska odnotowuje wyraźny wzrost PKB na przestrzeni ostatnich lat, co świadczy o dynamicznym rozwoju gospodarczym. 

Stabilna stopa bezrobocia stanowi wskaźnik społeczno-ekonomiczny, który odzwierciedla zdolność rynku pracy do absorbowania siły roboczej. Niskie s
