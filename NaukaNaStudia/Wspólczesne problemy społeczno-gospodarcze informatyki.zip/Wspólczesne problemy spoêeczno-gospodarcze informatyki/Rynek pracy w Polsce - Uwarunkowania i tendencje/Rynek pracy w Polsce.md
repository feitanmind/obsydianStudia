[[Popyt]]
[[Podaż]]
[[Paradoksy]]
[[Równowaga na Rynku Pracy w Polsce]]
