


<table>
<tr>
<td>
<b>Eurostat</b> mierzy <b>zharmonizowaną stopę bezrobocia </b> jako procent osób w wieku 15-74 lat, które pozostają bez pracy, są zdolne do podjęcia zatrudnienia w ciągu najbliższych dwóch tygodni i aktywnie poszukiwały pracy w ciągu ostatnich tygodni, w odniesieniu do wszystkich osób aktywnych zawodowo w danym kraju
</td>
<td>
<b>Główny Urząd Statystyczny (GUS)</b> prezentuje dane dotyczące bezrobocia, korzystając z dwóch źródeł:<br/>
1. <b>Rejestracja osób bezrobotnych w powiatowych urzędach pracy: </b>Na tej podstawie obliczana jest stopa bezrobocia rejestrowanego. Jest to wskaźnik obliczany z częstotliwością miesięczną na koniec okresu sprawozdawczego, którym jest koniec miesiąca<br/>
2. <b>Badanie Aktywności Ekonomicznej Ludności (BAEL): </b>Jest to reprezentacyjne badanie realizowane w Polsce w cyklu kwartalnym. Wyniki BAEL pozwalają na wyliczenie stopy bezrobocia wg BAEL, która jest publikowana co kwartał. Metodologia BAEL opera się na standardach Międzynarodowej Organizacji Pracy.
</td>
</tr>
</table>
