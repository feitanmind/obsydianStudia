**Wskaźnik zatrudnienia** to istotny miernik, który informuje o aktywności zawodowej ludności w danym kraju. Obejmuje zarówno osoby pracujące, jak i te, które są bezrobotne, ale aktywnie poszukują zatrudnienia. 

---
**Wskaźnik zatrudnienia** to **stosunek liczby osób pracujących do ogólnej liczby osób w wieku produkcyjnym** (czyli tych, które mogą legalnie pracować). Jest wyrażany w procentach.