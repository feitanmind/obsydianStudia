Ogólne skutki bezrobocia:
- Poczucie wykluczenia ze społeczeństwa
- Utrata statusu społecznego
- Pogarszające się relacje z rodziną i bliskimi
- Patologie społeczne
- Bieda i ubóstwo
- Niezakładanie rodzin
- Depresja i zaburzenia emocjonalne
- Niska samoocena
- Zrezygnowanie i niechęć do poszukiwania pracy