**Aktywizacja zawodowa**:
- Programy szkoleń i kursów
- Doradztwo zawodowe
- Staże
- Roboty publiczne
**Wspieranie przedsiębiorczości:**
- Dotacje i ulgi podatkowe
- Inkubatory przedsiębiorczości
**Usprawnianie systemu edukacji:**
- Dostosowanie programów nauczanie do potrzeb na rynku pracy
- Współpraca szkół z pracodawcami
**Inne działania:**
- Zwiększanie inwestycji
- Usprawnianie administracji
