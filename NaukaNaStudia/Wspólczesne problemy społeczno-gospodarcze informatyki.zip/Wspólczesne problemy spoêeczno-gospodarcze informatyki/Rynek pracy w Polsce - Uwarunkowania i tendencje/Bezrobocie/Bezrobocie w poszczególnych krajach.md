#### Bezrobocie w Grecji
- Kryzys gospodarczy
- Niewydolność sektora publicznego
- Wysokie zadłużenie
- Niewystarczające inwestycje
- Brak konkurencyjności
- Utrudniony dostęp do rynku pracy
#### Bezrobocie w Szwecji
- Imigracja
- Niewystarczające kwalifikacje
- Dyskryminacja
- Długotrwałe bezrobocie
- Słabe warunki gospodarcze
- Problemy strukturalne
#### Bezrobocie w Anglii
- Brexit
- Automatyzacja
- Pandemia COVID
- Niedopasowane umiejętności
- Demografia