**Na podstawie przyczyn:**
- Bezrobocie frykcyjne - za mało miejsc pracy na rynku przez krótki okres czasu. Jest związane z niedostateczną informacją.
- Bezrobocie strukturalne - frykcyjne tylko przez dłuży czas. Kandydaci nie mają wystarczającego wykształcenia lub kompetencji.
- Bezrobocie koniunkturalne - cykliczne. Związane z cyklicznymi zmianami gospodarki
- Bezrobocie sezonowe - dotyczy sezonów np. prace wakacyjne

**Na podstawie jawności:**
- Bezrobocie jawne - np. rejestrowane bezrobocie w urzędach pracy
- Bezrobocie ukryte - wcześniejsza emerytura lub niepełny wymiar pracy

**Na podstawie okresu trwania:**
- Bezrobocie krótkookresowe - do 3 miesięcy
- Bezrobocie średniookresowe - od 4 do 6 miesięcy
- Bezrobocie długookresowe - od 7 do 12 miesięcy
- Bezrobocie długotrwałe - powyżej roku