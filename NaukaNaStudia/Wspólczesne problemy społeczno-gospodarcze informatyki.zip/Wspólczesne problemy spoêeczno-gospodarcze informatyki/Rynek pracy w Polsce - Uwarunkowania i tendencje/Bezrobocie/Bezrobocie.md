**Bezrobocie** - zjawisko społeczne, które przejawia się tym, iż grupa ludzi zdolnych i chętnych do pracy, nie jest w stanie podjąć zatrudnienia. Bezrobotny nie jest nigdzie zatrudniony, nie prowadzi działalności gospodarczej ani żadnej innej pracy zarobkowej.
Międzynarodowa Organizacja Pracy za bezrobotnego uznaje osobę w wieku 15-74 lat, która spełnia warunki:
- w okresie badanego tygodnia nie była osobą pracującą
- aktywnie poszukiwała pracy
- była gotowa podjąć pracę w badanym tygodniu lub następnym

[[Jak Eurostat i GUS mierzą stopę bezrobocia]]
[[Wskaźnik zatrudnienia]]
[[Podział bezrobocia]]
[[Skutki bezrobocia]]
[[Czynniki wpływające na wzrost bezrobocia w Polsce]]
[[Działania przeciw bezrobociu]]
[[Porównanie Polski i innych krajów w kontekście bezrobocia]]
[[Bezrobocie w poszczególnych krajach]]