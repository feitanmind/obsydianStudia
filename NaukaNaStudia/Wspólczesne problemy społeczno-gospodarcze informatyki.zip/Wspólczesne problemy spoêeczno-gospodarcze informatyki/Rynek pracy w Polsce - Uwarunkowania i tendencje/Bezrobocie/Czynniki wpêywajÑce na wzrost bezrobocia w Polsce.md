1. Wojna Rosji z Ukrainą, czyli napływ uchodźców do Polski, zabieranie stanowisk pracy na Polskim rynku
2. Zmiany demograficzne - starzejące się społeczeństwo
3. Spowolnienie gospodarcze - wzrost inflacji i stóp procentowych