**Równowaga na rynku pracy** to sytuacja, w której popyt na pracę jest równy podaży pracy przy danej płacy. Oznacza to, że ilość oferowanych miejsc pracy przez pracodawców jest dokładnie zrównoważona z liczbą pracowników poszukujących zatrudnienia. W takim przypadku nie ma nadwyżki ani niedoboru pracowników na tynku.
[[Popyt na pracę]] reprezentowany jest przez pracodawców, którzy oferują miejsca pracy.
[[Podaż pracy]] reprezentowana jest przez osoby poszukujące zatrudnienia.

Równowaga na rynku pracy występuje wtedy, gdy liczba pracowników gotowych do pracy jest dokładnie taka sama jak liczba oferowanych miejsc pracy.

---
**Segmentacja rynku pracy** - Polski rynek pracy jest zróżnicowany pod względem sektorów i typów zatrudnienia. Istnieje segmentacja na rynek pierwszej pracy, rynek pracy dla wykształconych specjalistów, rynek pracy dla niewykwalifikowanych pracowników itp.
Wpływ na to ma m.in. poziom wykształcenia, doświadczenia zawodowe i umiejętności. 
**Tendencje i wyzwania** - Polska gospodarka staje przez wyzwaniami związanymi z starzeniem się społeczeństwa i emigracją zarobkową.