**Popyt na pracę** oznacza liczbę miejsc pracy, które pracodawcy chcą zatrudnić przy określonej stawce płac. Jest to zapotrzebowanie gospodarki na potencjał ludzi zdolnych do pracy. Pracodawcy decydują się na zatrudnienie pracowników w zamian za określone wynagrodzenie. 

Popyt na pracę jest zależny od wielu czynników, takich jak koszty pracy, wydajność pracy, koniunktura gospodarcza, zmiany technologii produkcji i czynniki społeczne. 
W okresach ożywienia gospodarczego, popyt na pracę rośnie, a w okresie recesji maleje.